<?php
$cart = Cart::getInstance();
$cart->clear();
?>