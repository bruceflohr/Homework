<?php
    include 'filterHelper.php';

    //include 'models/housesModel.php';
    //include 'views/homeView.php';
?>