<?php
    include 'filterHelper.php';

    include 'models/housesModel.php';
    //set_include_path("C:/xampp/htdocs/class/PHP/66/realestate/views");
    include 'views/housesTableView.php';
?>